setwd("C:\\Users\\MSI GF63\\Desktop\\IT24101049")
getwd()

##Exercise 01
#Part 1
#Binomial Distribution

#Part2
#Rearrange:P(X>=47)=1-P(X<=46)
1-pbinom(46, 50, 0.85, lower.tail = TRUE)

##Exercise 02
#Part 1
#Number of customer calls received in the call center per hour

#Part 2
#Poisson distribution
# random variable X has poisson distribution with lambda = 12

#Part 3
dpois(15,12)